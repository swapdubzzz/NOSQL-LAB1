# NoSql-Lab1-Hadoop
This Lab consists of Map Reduce programs on Hadoop.

**Question 2:** Input file consists of the NCDC weather data and the Map Reduce program returns yearly the Maximum Temperature recorded.

**Question 3:** Input file consists of web access log roduced by a web server and the Map Reduce program counts the number of times GIF, JPG, and other image files that have been accessed by clients.

**Question 4:** With the same input file as above, the Map Reduce program outputs Total number of requests and Total download size on Monthly basis.

**Question 5:** With the same input file as above, the Map Reduce program lists Timestamp, URL for which http response status has been **404**.
